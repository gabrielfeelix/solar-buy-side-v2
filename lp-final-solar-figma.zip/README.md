
  # Greeting message (Copy)

  This is a code bundle for Greeting message (Copy). The original project is available at https://www.figma.com/design/nRa6kaw3rc8lR7T6GquNrp/Greeting-message--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  